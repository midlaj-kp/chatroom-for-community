// public/script.js
const socket = io();
const params = new URLSearchParams(window.location.search);
const username = params.get('username');
const room = params.get('room');

document.getElementById('room-title').textContent = `Room: ${room}`;
socket.emit('joinRoom', { username, room });

const form = document.getElementById('chat-form');
const msgInput = document.getElementById('msg');
const messagesDiv = document.getElementById('messages');
const fileInput = document.getElementById('file-upload');

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const msg = msgInput.value;

  if (fileInput.files.length > 0) {
    const formData = new FormData();
    formData.append('file', fileInput.files[0]);

    const res = await fetch('/upload', {
      method: 'POST',
      body: formData
    });

    const data = await res.json();
    socket.emit('chatMessage', `${username} shared: <a href="${data.path}" target="_blank">${data.originalName}</a>`);
    fileInput.value = '';
  }

  if (msg.trim()) {
    socket.emit('chatMessage', msg);
  }

  msgInput.value = '';
});

socket.on('message', msg => {
  const div = document.createElement('div');
  div.className = msg.username === username ? 'message sender' : 'message receiver';
  div.innerHTML = `<strong>${msg.username}:</strong> ${msg.text}`;
  messagesDiv.appendChild(div);
  messagesDiv.scrollTop = messagesDiv.scrollHeight;
});
