// server.js
const express = require('express');
const app = express();
const http = require('http');
const { Server } = require('socket.io');
const multer = require('multer');
const path = require('path');

const server = http.createServer(app);
const io = new Server(server);
const rooms = new Set();

app.use(express.static('public'));

const storage = multer.diskStorage({
  destination: './uploads/',
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`);
  }
});
const upload = multer({ storage });

app.post('/upload', upload.single('file'), (req, res) => {
  res.json({ path: `/uploads/${req.file.filename}`, originalName: req.file.originalname });
});

app.get('/check-room', (req, res) => {
  const room = req.query.room;
  res.json({ exists: rooms.has(room) });
});

io.on('connection', socket => {
  socket.on('joinRoom', ({ username, room }) => {
    socket.join(room);
    socket.username = username;
    socket.room = room;

    if (!rooms.has(room)) rooms.add(room);

    socket.to(room).emit('message', { username: 'System', text: `${username} joined the room.` });
  });

  socket.on('chatMessage', msg => {
    io.to(socket.room).emit('message', { username: socket.username, text: msg });
  });

  socket.on('disconnect', () => {
    if (socket.room) {
      socket.to(socket.room).emit('message', { username: 'System', text: `${socket.username} left the room.` });
    }
  });
});

server.listen(3000, () => console.log('Server started on http://localhost:3000'));
